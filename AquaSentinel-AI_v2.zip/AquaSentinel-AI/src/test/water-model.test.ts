import { describe, expect, it } from "vitest";
import { assess, computeIndex, modifiedZScore, oxygenSaturation, statusFromSubIndex, subIndex } from "@/lib/water/model";
import { sampleFormSchema } from "@/lib/water/validation";
import { buildDemoSamples } from "@/lib/water/demo-data";
import { buildReport } from "@/lib/water/report";

const clean = { ph: 7.4, turbidity: 0.5, dissolvedOxygen: 8.5, conductivity: 300, temperature: 20 };

describe("water-quality model", () => {
  it("oxygen saturation at 20 °C is about 9.09 mg/L (Benson & Krause)", () => {
    expect(oxygenSaturation(20)).toBeCloseTo(9.09, 1);
  });

  it("pH 6.5–8.5 scores as within reference; 5.0 is far outside", () => {
    expect(statusFromSubIndex(subIndex("ph", { ...clean, ph: 6.5 }))).toBe("normal");
    expect(statusFromSubIndex(subIndex("ph", { ...clean, ph: 8.5 }))).toBe("normal");
    expect(statusFromSubIndex(subIndex("ph", { ...clean, ph: 5.0 }))).toBe("critical");
  });

  it("clean readings are classified excellent with no investigation", () => {
    const a = assess(clean);
    expect(a.category).toBe("excellent");
    expect(a.requiresInvestigation).toBe(false);
  });

  it("one severe parameter cannot be averaged away (guard caps class at poor)", () => {
    const r = computeIndex({ ...clean, ph: 4 });
    expect(r.wqi).toBeGreaterThan(70);
    expect(r.category).toBe("poor");
  });

  it("turbidity of 30 NTU requires investigation", () => {
    expect(assess({ ...clean, turbidity: 30 }).requiresInvestigation).toBe(true);
  });

  it("uncertainty analysis is deterministic and between 0 and 1", () => {
    const a = assess(clean).uncertainty!;
    const b = assess(clean).uncertainty!;
    expect(a.stability).toBe(b.stability);
    expect(a.stability).toBeGreaterThan(0.9);
  });

  it("modified z-score flags a value far from history and needs 8 samples", () => {
    const hist = [300, 310, 305, 295, 290, 315, 300, 308];
    expect(modifiedZScore(2000, hist)!).toBeGreaterThan(3.5);
    expect(modifiedZScore(2000, hist.slice(0, 7))).toBeNull();
  });

  it("report always recommends microbiological testing", () => {
    const s = buildDemoSamples()[0]!;
    const r = buildReport(s, assess(s));
    expect(r.tests[0]?.test).toMatch(/E\. coli/);
    expect(r.disclaimer).toMatch(/does NOT determine whether water is safe to drink/);
  });
});

describe("form validation", () => {
  const valid = {
    label: "Test", siteName: "Pond", waterSource: "lake" as const, collectedAt: "2026-01-10", latitude: "", longitude: "",
    ph: "7.1", turbidity: "2", dissolvedOxygen: "8", conductivity: "400", temperature: "21", notes: "",
  };
  it("accepts valid input", () => {
    expect(sampleFormSchema.safeParse(valid).success).toBe(true);
  });
  it("rejects pH above 14", () => {
    expect(sampleFormSchema.safeParse({ ...valid, ph: "15" }).success).toBe(false);
  });
  it("rejects text in a numeric field", () => {
    expect(sampleFormSchema.safeParse({ ...valid, turbidity: "abc" }).success).toBe(false);
  });
  it("requires both coordinates or neither", () => {
    expect(sampleFormSchema.safeParse({ ...valid, latitude: "22.5" }).success).toBe(false);
  });
});

describe("demo data", () => {
  it("every demo sample is labelled as demonstration data", () => {
    const d = buildDemoSamples();
    expect(d.length).toBe(56);
    expect(d.every((s) => s.isDemo)).toBe(true);
  });
});
