import { describe, expect, it } from "vitest";
import { parseMlResponse } from "@/lib/water/ml";

const meta = { input: { conductivity: 309, turbidity: 85.1, temperature: 29 }, checkedAt: "2026-11-17T16:00:00.000Z", latencyMs: 300, endpoint: "x/predict" };

describe("Isolation Forest backend response handling", () => {
  it("passes through a real Anomaly answer unchanged", () => {
    const r = parseMlResponse(200, { prediction: -1, status: "Anomaly", model: "Isolation Forest", warning: "Anomaly detection does not confirm water contamination." }, meta);
    expect(r.ok && r.result.status).toBe("Anomaly");
    expect(r.ok && r.result.prediction).toBe(-1);
  });

  it("passes through a real Normal answer", () => {
    const r = parseMlResponse(200, { prediction: 1, status: "Normal", model: "Isolation Forest" }, meta);
    expect(r.ok && r.result.status).toBe("Normal");
  });

  it("rejects a contradictory answer instead of guessing", () => {
    expect(parseMlResponse(200, { prediction: 1, status: "Anomaly", model: "Isolation Forest" }, meta).ok).toBe(false);
  });

  it("rejects an unexpected response shape", () => {
    expect(parseMlResponse(200, { result: "ok" }, meta).ok).toBe(false);
  });

  it("explains a 422 validation error naming the field", () => {
    const r = parseMlResponse(422, { detail: [{ loc: ["body", "turbidity"], msg: "Field required" }] }, meta);
    expect(r.ok).toBe(false);
    expect(!r.ok && r.message).toContain("turbidity");
  });

  it("reports server errors as failures", () => {
    const r = parseMlResponse(503, null, meta);
    expect(!r.ok && r.kind).toBe("http");
  });
});
